// �x�s�ɦW�Gd:\Chap03\J306_SumTen.java

public class J306_SumTen
{
	public static void main(String[] args)
	{
		int count, sum = 0;
		for (count = 1; count <= 10; count ++)	// count<=10�j�馨��
			sum += count;	// sum=sum+count
		System.out.println("1 + 2 + 3 + ... + 10 = " + sum);	// ��X�r��P�`�M
	}
}
