import java.applet.Applet;
import java.awt.*;

public class J901_Applet extends Applet
{
	public void paint(Graphics g)
	{
		g.drawString("�١A�j�a�n�I", 70, 100);	//��ܦr��
	}
}
