//�x�s�ɦW�Gd:\Chap02\J213_Power.java

public class J213_Power
{
	public static void main(String[] args)
	{
		double a = Math.pow(2, 3);
		double b = Math.sqrt(2);
		System.out.println("2 �� 3 ���� = " + a);
		System.out.println("�ڸ� 2 = " + b);
	}
}
