//�x�s�ɦW�Gd:\Chap02\J217_Random.java

public class J217_Random
{
	public static void main(String[] args)
	{
		double a = Math.random();	//a=�ü�
		System.out.println("a = " + a);	//��X�ü�
	}
}
