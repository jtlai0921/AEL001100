//�x�s�ɦW�Gd:\Chap02\J212_Exponential.java

public class J212_Exponential
{
	public static void main(String[] args)
	{
		double a = Math.exp(2);		//e2
		double b = Math.log(2);		//ln 2
		double c = Math.log(2)/Math.log(10);		//log 2
		System.out.println("e*e = " + a);
		System.out.println("ln 2 = " + b);
		System.out.println("log 2 = " + c);
	}
}
